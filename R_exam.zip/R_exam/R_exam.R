# rss구하는 함수 정의

rss <- function(y, yhat){
  sum((y-yhat)^2)
}


# 1. mtcars 데이터를 불러온 후,
# - 전체 32개의 관측치 중 25개를 train, 7개를 test 데이터로 나누어 작업
# - mpg를 종속변수로 두고 다양한 회귀 모델 작성

mtcars
str(mtcars)

# 각 변수와  mpg간의 관계를 보기 위해 산점도 그려 확인

par(mfrow=c(4,3))
plot(mtcars$cyl, mtcars$mpg) #4>5>6
plot(mtcars$disp, mtcars$mpg)  #음
plot(mtcars$hp, mtcars$mpg)  #음
plot(mtcars$drat, mtcars$mpg)  #양(분포 넓은 편)
plot(mtcars$wt, mtcars$mpg)  #음
plot(mtcars$qsec, mtcars$mpg)  #양(분포 넓은 편)
plot(mtcars$vs, mtcars$mpg)  #0<1
plot(mtcars$am, mtcars$mpg)  #0<1
plot(mtcars$gear, mtcars$mpg)  #3<4
plot(mtcars$carb, mtcars$mpg)  #작을수록 > 높을수록
dev.off()

# 1. 이상치 제거 하고 진행한 경우

par(mfrow=c(4,3))
apply(mtcars, 2, boxplot)  #hp(1), wt(2), qsec(1), crab(1) 
dev.off()

box_hp <- boxplot(mtcars$hp)
out_idx <- which(mtcars$hp %in% box_hp$out)

box_wt <- boxplot(mtcars$wt)
out_idx <- c(out_idx, which(mtcars$wt %in% box_wt$out))

box_gsec <- boxplot(mtcars$qsec)
out_idx <- c(out_idx, which(mtcars$qsec %in% box_gsec$out))
out_idx

# crab은 측정값이 아니라서 제거하지 않았습니다.

newMtcars <- mtcars[-out_idx,]

set.seed(03191)
mttest_idx <- sample(1:nrow(newMtcars), 7)
mttrain <- newMtcars[-mttest_idx,]
mttest <- newMtcars[mttest_idx,-1]
mttestLabels <- newMtcars[mttest_idx,1]

# 모든 변수에 대해 mpg와의 다중회귀분석 진행한 경우

mt_model1 <- lm(mpg ~ ., mttrain)
summary(mt_model1)
# Multiple R-squared:  0.9422,	Adjusted R-squared:  0.8844 
# F-statistic: 16.31 on 10 and 10 DF,  p-value: 6.667e-05

mttestPred1 <- predict(mt_model1, mttest)

rss(mttestLabels, mttestPred1)  #297.3845


# 2. 이상치 제거하지 않고 모든 변수에 대해 mpg와의 다중회귀분석 진행한 경우
# 이상치를 제거하에는 데이터가 너무 부족해 이상치 포함해 진행해보았습니다

mtcars
set.seed(03192)
mttest_idx <- sample(1:nrow(mtcars), 7)
mttrain <- mtcars[-mttest_idx,]
mttest <- mtcars[mttest_idx,-1]
mttestLabels <- mtcars[mttest_idx,1]

# 모든 변수에 대해 mpg와의 다중회귀분석 진행한 경우

mt_model2 <- lm(mpg ~ ., mttrain)
summary(mt_model2)
# Multiple R-squared:  0.9026,	Adjusted R-squared:  0.833 
# F-statistic: 12.97 on 10 and 14 DF,  p-value: 1.927e-05

mttestPred2 <- predict(mt_model2, mttest)
rss(mttestLabels, mttestPred2)  #162.6014

# 오히려 이상치를 제거하지 않은 경우가 정확도가 더 높았다.
# 따라서 이상치 제거하지 않은 상태로 진행한다


# 3. 선형성이 잘 보이지 않았던 drat열과 qsec열을 제외한 경우

str(mttrain)

mt_model3 <- lm(mpg ~ ., mttrain[,-c(5,7)])
summary(mt_model3)
# Multiple R-squared:  0.8822,	Adjusted R-squared:  0.8233 
# F-statistic: 14.98 on 8 and 16 DF,  p-value: 4.398e-06

mttestPred3 <- predict(mt_model3, mttest)
rss(mttestLabels, mttestPred3)  #80.30529

# 정확도 상승!(162.6014 -> 80.30529 : rss 감소!)


plot(1:7, mttestLabels,
     cex = .8, type = "o", col = "red", pch=20,
     main = "실제값과 예측값 비교",
     xlab = "",
     ylab = "mpg",
     ylim = c(0, 40))
lines(1:7, mttestPred3,
      cex = .8,type = "o", col = "blue", pch=43)
legend("topright", 
       legend = c("Labels","Pred"),
       pch = c(20, 43),
       cex = .8,
       col = c("red", "blue"))

# 신뢰구간
str(mttest)
mt_conf_data <- cbind(mttestLabels, mttest[,-c(4,6)])
mt_confidence <- lm(mttestLabels ~ ., mt_conf_data)

p <- predict(mt_confidence, interval = "confidence")
head(p)

x <- c(1:7, tail(1:7,1), rev(1:7), 1)
y <- c(p[,"lwr"], tail(p[,"upr"],1), rev(p[,"upr"]), p[,"lwr"][1])

polygon(x,y,col = rgb(.7, .7, .7, .2))


# 3. vs와 am은 0 또는 1의 값으로 factor형 자료로 볼 수 있다
# vs : 0(v자형), 1(직선형)
# am : 0(자동), 1(수동)
# 이를 기준으로 나누어 생각해보자


# 3-1) vs를 기준으로 나누고 나머지를 고려해보자

str(mttrain)
vs_l <- mttrain[mttrain$vs == 0,-c(5,7,8)]
vs_v <- mttrain[mttrain$vs == 1,-c(5,7,8)]

mt_model40 <- lm(mpg ~ ., vs_l)
summary(mt_model40)
# Multiple R-squared:  0.9409,	Adjusted R-squared:  0.8719 
# F-statistic: 13.64 on 7 and 6 DF,  p-value: 0.002663

mt_model41 <- lm(mpg ~ ., vs_v)
summary(mt_model41)
# Multiple R-squared:  0.9258,	Adjusted R-squared:  0.7526 
# F-statistic: 5.347 on 7 and 3 DF,  p-value: 0.09807

head(mttest)
mttestPred4 <- ifelse(mttest$vs == 0,
                      predict(mt_model40, mttest[,-c(4,6,7)]),
                      predict(mt_model41, mttest[,-c(4,6,7)]))

rss(mttestLabels, mttestPred4)  #3106.927

# 오히려 정확성이 더 떨어졌다

# 3-2) am를 기준으로 나누고 나머지를 고려해보자

str(mttrain)
am_o <- mttrain[mttrain$am == 0,-c(5,7,9)]
am_s <- mttrain[mttrain$am == 1,-c(5,7,9)]

mt_model50 <- lm(mpg ~ ., am_o)
summary(mt_model50)
# Multiple R-squared:  0.8998,	Adjusted R-squared:  0.7828 
# F-statistic: 7.693 on 7 and 6 DF,  p-value: 0.01197

mt_model51 <- lm(mpg ~ ., am_s)
summary(mt_model51)
# Multiple R-squared:  0.9602,	Adjusted R-squared:  0.8672 
# F-statistic: 10.33 on 7 and 3 DF,  p-value: 0.04065

head(mttest)
mttestPred5 <- ifelse(mttest$am == 0,
                      predict(mt_model50, mttest[,-c(4,6,8)]),
                      predict(mt_model51, mttest[,-c(4,6,8)]))

rss(mttestLabels, mttestPred5)  #4522.834





# 2. yahoo.finance.com에서 최근 1년 동안의(2020.3.18~2021.3.18) 
# 삼성전자 주식 데이터를 다운로드 후, 종가를 예측하는 모델을 만드시오.
# (위 기간을 다르게 설정해도 관계없습니다)

samsung <- read.csv("005930.KS.csv") 
str(samsung)

apply(samsung, 2, FUN = function(x){sum(is.na(x))}) #결측값 없음


# 2) 데이터 분석
# - 월/분기별 최대/최소값 등 통계치

# 월별 최대/최소값

samsung$Month <- format(as.Date(samsung$Date), format="%Y%m")
m <- unique(samsung$Month)
m

monthly_data <- NULL
for(i in m){
  max <- apply(samsung[samsung$Month == i,-c(1,8)], 2, max)
  min <- apply(samsung[samsung$Month == i,-c(1,8)], 2, min)
  monthly_data <- rbind(monthly_data, max, min)
}
rownames(monthly_data) <- paste(rep(m, each=2), rownames(monthly_data), sep = "_")

monthly_data

# - 월별 주가 변화 시각화

str(samsung)

monthly_mean <- NULL
for(i in m){
  m_mean <- mean(samsung[samsung$Month == i,6])
  monthly_mean <- c(monthly_mean, m_mean)
}
monthly_mean

m_plot <- plot(1:length(m), monthly_mean,
     cex = .8, type = "o", col = "red", pch=20,
     main = "월별 주가변화",
     xlab = "날짜",
     ylab = "가격",
     )
text(m_plot, monthly_mean,
     labels = monthly_mean,
     pos=3, cex = 0.8)
dev.off()

# 분기별 최대/최소값

samsung$Quarter <- paste(substr(samsung$Month, 3, 4), 
                         quarters(as.Date(samsung$Date)), sep="/")
q <- unique(samsung$Quarter)
q

quarter_data <- NULL
for(i in q){
  max <- apply(samsung[samsung$Quarter == i,-c(1,8,9)], 2, max)
  min <- apply(samsung[samsung$Quarter == i,-c(1,8,9)], 2, min)
  quarter_data <- rbind(quarter_data, max, min)
}
rownames(quarter_data) <- paste(rep(q, each=2), rownames(quarter_data), sep = "_")

quarter_data


# - 분기별 주가 변화 시각화

quarter_mean <- NULL
for(i in q){
  q_mean <- mean(samsung[samsung$Quarter == i,6])
  quarter_mean <- c(quarter_mean, q_mean)
}
quarter_mean

plot(1:length(q), quarter_mean,
     cex = .8, type = "o", col = "red", pch=20,
     main = "분기별 주가변화",
     xlab = "분기",
     ylab = "가격")
dev.off()


# - 전체 기간 중 최고/최저 주가

samsung[samsung$Adj.Close == max(samsung$Adj.Close), c(1,6)]
#           Date   Adj.Close
# 202 2021-01-11       91000

samsung[samsung$Adj.Close == min(samsung$Adj.Close), c(1,6)]
#         Date    Adj.Close
# 4 2020-03-23     40629.57



# 1) 데이터 분리
# train 데이터 : 2020년 3월 18일~2021년 2월 18일(11개월)
# test 데이터 : 2021년 2월 19일~3월 18일까지 (1개월)

str(samsung)

# 이상치 제거

par(mfrow=c(2,3))
apply(samsung[,-1], 2, boxplot)  #vol에만 존재
dev.off()

box_vol <- boxplot(samsung$Volume)
out_idx <- which(samsung$Volume %in% box_vol$out)
ss_rem_out <- samsung[-out_idx,]

testDay <- as.character(seq(from=as.Date("2021/02/19"), to=as.Date("2021/03/18"), by=1))
sstest_idx <- which(ss_rem_out$Date %in% testDay)

# Adj.Close는 Close로부터 얻는 것이므로 제거한 뒤 진행하였습니다.

sstrain <- ss_rem_out[-sstest_idx,c(2:5,7)]
head(sstrain)
sstest <- ss_rem_out[sstest_idx,c(2:4,7)]
head(sstest)
sstestLabels <- ss_rem_out[sstest_idx,5]


# 3) 모델 작성 및 예측
# test데이터로 종가를 예측하고,
# 실제 종가와 비교하여 rss(잔차 제곱의 합)를 구하시오.

par(mfrow=c(2,2))
plot(sstrain$Open, sstrain$Close)  #선형, 양
plot(sstrain$High, sstrain$Close)  #선형, 양
plot(sstrain$Low, sstrain$Close)  #선형, 양
plot(sstrain$Volume, sstrain$Close)  #분포일 뿐 규칙성을 보이지는 않음
dev.off()


# 모든 열을 close(종가)와 다중회귀분석 진행한 경우

ss_model1 <- lm(sstrain$Close ~ ., sstrain)
summary(ss_model1)
# Multiple R-squared:  0.9988,	Adjusted R-squared:  0.9988 
# F-statistic: 4.451e+04 on 4 and 212 DF,  p-value: < 2.2e-16

sstestPred1 <- predict(ss_model1, sstest)
rss(sstestLabels, sstestPred1)  #5,674,314

# 선형성을 보이지 않았던  volume 열을 제외하고 다중회귀분석 진행한 경우
# 이상치를 가지고 있던 volume 열을 제외하고 진행하므로
# 최대한 많은 자료를 활용하기 위해 이상치를 제거하기 이전의 데이터인
# samsung 데이터에서 train과 test를 생성하여 활용하기로 했습니다.

testDay <- as.character(seq(from=as.Date("2021/02/19"), to=as.Date("2021/03/18"), by=1))
sstest_idx <- which(samsung$Date %in% testDay)

sstrain <- samsung[-sstest_idx,c(2:5,7)]
sstest <- samsung[sstest_idx,c(2:4,7)]
sstestLabels <- samsung[sstest_idx,5]

ss_model2 <- lm(Close ~ ., sstrain[,-5])
summary(ss_model2)
# Multiple R-squared:  0.9983,	Adjusted R-squared:  0.9983 
# F-statistic: 4.492e+04 on 3 and 224 DF,  p-value: < 2.2e-16

sstestPred2 <- predict(ss_model2, sstest)
rss(sstestLabels, sstestPred2)  #5,173,823

# volume열을 포함한 경우보다 rss가 더 작다 => 더 정확하다


# Open열만 단순회귀분석 진행할 경우

ss_model3 <- lm(Close ~ Open, sstrain)
summary(ss_model3)
# Multiple R-squared:  0.9919,	Adjusted R-squared:  0.9919 
# F-statistic: 2.77e+04 on 1 and 226 DF,  p-value: < 2.2e-16

sstestPred3 <- predict(ss_model3, sstest)
rss(sstestLabels, sstestPred3)  #15,077,408


# Low열만 단순회귀분석 진행할 경우

ss_model4 <- lm(Close ~ Low, sstrain)
summary(ss_model4)
# Multiple R-squared:  0.9958,	Adjusted R-squared:  0.9958 
# F-statistic: 5.359e+04 on 1 and 226 DF,  p-value: < 2.2e-16

sstestPred4 <- predict(ss_model4, sstest)
rss(sstestLabels, sstestPred4)  #7,755,049

# High열만 단쉰회귀분석 진행한 경우

ss_model5 <- lm(Close ~ High, sstrain)
summary(ss_model5)
# Multiple R-squared:  0.9967,	Adjusted R-squared:  0.9966 
# F-statistic: 6.738e+04 on 1 and 226 DF,  p-value: < 2.2e-16

sstestPred5 <- predict(ss_model5, sstest)
rss(sstestLabels, sstestPred5)  #9,536,647


# Low열과 High열로 다중회귀분석 진행한 경우
# Open열의 경우, 위의 단순회귀분석에서 
# rss값이 너무 커지는 것을 확인했으므로 이를 제외한 Low열과 High열만 포함시켰습니다

ss_model6 <- lm(Close ~ Low+High, sstrain)
summary(ss_model6)
# Multiple R-squared:  0.9975,	Adjusted R-squared:  0.9974 
# F-statistic: 4.438e+04 on 2 and 225 DF,  p-value: < 2.2e-16

sstestPred6 <- predict(ss_model6, sstest)
rss(sstestLabels, sstestPred6)  #5,072,980

# 정확도 상승!! (5,173,823 -> 5,072,980 : rss 감소!)

# 결과 시각화

sstestDay <- as.Date(samsung$Date[sstest_idx])

plot(sstestDay, sstestLabels,
     cex = .8, type = "o", col = "red", pch=20,
     main = "실제값과 예측값 비교",
     xlab = "날짜",
     ylab = "종가")
lines(sstestDay, sstestPred6,
      cex = .8,type = "o", col = "blue", pch=43)
legend("topright", 
       legend = c("Labels","Pred"),
       pch = c(20, 43),
       cex = .8,
       col = c("red", "blue"))

# 신뢰구간

ss_confidence <- lm(sstestLabels ~ sstest$High+sstest$Low)

p <- predict(ss_confidence, interval = "confidence")
head(p)

x <- c(sstestDay, tail(sstestDay,1), rev(sstestDay), sstestDay[1])
y <- c(p[,"lwr"], tail(p[,"upr"],1), rev(p[,"upr"]), p[,"lwr"][1])

polygon(x,y,col = rgb(.7, .7, .7, .2))
